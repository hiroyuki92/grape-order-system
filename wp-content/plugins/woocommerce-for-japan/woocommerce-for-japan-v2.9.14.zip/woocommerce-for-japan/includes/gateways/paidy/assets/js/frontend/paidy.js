( () => {
	'use strict';
	const e = window.React,
		t = window.wc.wcBlocksRegistry,
		n = window.wp.i18n,
		a = window.wc.wcSettings,
		i = window.wp.htmlEntities,
		o = window.wp.element,
		c = ( 0, a.getPaymentMethodData )( 'paidy', {} ),
		l = ( 0, n.__ )( 'Paidy', 'woocommerce-for-japan' ),
		w = ( 0, i.decodeEntities )( c?.title || '' ) || l,
		r = c.description + c.paidy_description,
		d = () => ( 0, e.createElement )( o.RawHTML, null, r || '' ),
		s = {
			name: 'paidy',
			label: ( 0, e.createElement )( ( t ) => {
				const { PaymentMethodLabel: n } = t.components;
				return ( 0, e.createElement )( n, { text: w } );
			}, null ),
			content: ( 0, e.createElement )( d, null ),
			edit: ( 0, e.createElement )( d, null ),
			canMakePayment: () => ! 0,
			ariaLabel: w,
			supports: { features: c.supports },
		};
	( 0, t.registerPaymentMethod )( s );
} )();
